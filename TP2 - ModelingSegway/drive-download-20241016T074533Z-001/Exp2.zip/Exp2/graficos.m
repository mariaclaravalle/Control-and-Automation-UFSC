close all

%% Configuração de um grid na tela para gráficos

screenSize = get(0,'screensize'); % gets screen size
monWidth = screenSize(3);
monHeight = screenSize(4);

offHeight = 0; % assumed height of system task bar
monHeight = monHeight - offHeight; % usable screen height

% establishing a 2x3 grid on the screen
figHeight = monHeight/2;
figWidth = monWidth/3;

%% Gráficos com resultados para malha aberta

figure
subplot(2, 1, 1);
plot(out.d_xb.Time, out.d_xb.Data)
grid on
xlabel('tempo [s]')
ylabel('velocidade xb [m/s]')
title('Velocidade em xb e posição tetha em malha aberta')

subplot(2, 1, 2);
plot(out.tetha.Time,out.tetha.Data)
grid on
xlabel('tempo [s]')
ylabel('posição [tetha]')

%% Gráficos para malha fechada

figure
subplot(2, 1, 1);
plot(out.tetha_workspace.Time, out.tetha_workspace.Data)
grid on
hold on 
plot(out.ref.Time, out.ref.Data)
xlabel('tempo [s]')
ylabel('posição tetha [rad]')
title('Velocidade em xb e posição tetha com controle pi')
legend("Tetha", "Referência")


subplot(2, 1, 2);
plot(out.pi_1.Time,out.pi_1.Data)
grid on
hold on
plot(out.F.Time,out.F.Data)
xlabel('tempo [s]')
ylabel('ação de controle [N]')
legend("Controle PI", "Ação de controle total")