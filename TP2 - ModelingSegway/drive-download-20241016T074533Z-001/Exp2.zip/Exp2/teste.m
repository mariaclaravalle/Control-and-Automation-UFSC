l = 1; % 1m
M = 22.8; % 22.8kg
m = 70; % 70kg
g = 9.81; % 9.81 m/(s^2)
d = 25;
b = 100;


% fonte https://www.segway.com/ninebot-s-max/smax-specs/#specs-smax